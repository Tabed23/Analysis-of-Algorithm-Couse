#include<iostream>
#include<iomanip>
#include<vector>
using namespace std;
template<typename TM>
class Stack
{
private:
	vector<TM> data;
	int size;
	int top;
	int min;
	int max
public:
	Stack()
	{
		size = 10; // making a constant size because vector size will be double every time ! 
		top = -1;
	}
	~Stack()
	{

		data.erase(data.begin(), data.end());
		cout <<"Distructor has been called....!!"<<endl;
	}
	void push(TM element)
	{
		if(isEmpty())
		{
			top++;
			min = element;
			data.push_back(element);
			return;
		}
		if(isFull())
		{
			cout <<"stack is full";
			return;
		}
		if(element < min)
		{
			min =  element;
			max = element;
			data.push_back(element);
		}
		if(element > max)
		{
			max = element;
			data.push_back(element);
		}
		else
		{
			data.push_back(element);
		}

	}
	void pop()
	{
		data.pop_back();
		top--;
	}
	bool isEmpty()
	{
		return top == -1;
	}
	bool Search(TM element)
	{
		for (int i = 0; i < top; i++)
		{
			if (data[i] == element)
				return true;
		}
		return false;
	}
	TM Peek()const
	{
        return data[top];
	}
	void print()
	{
		for (auto itr : data)
		{
            cout <<"---"<<endl;
			cout << "|"<<itr<<"|"<<endl;
			cout <<"---"<<endl;
		}
	}
	bool isFull()
	{
		return top == size;
	}
	TM getMax()const
	{
		return  max;
	}
	TM getMin()const
	{
		return min;
	}
};